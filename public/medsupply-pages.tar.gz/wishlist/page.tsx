"use client";
import { useState, useEffect } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "https://medsupply.quanbyai.com";

interface WishlistItem {
  id: string;
  name: string;
  brand: string | null;
  model_number: string | null;
  unit_price: string | null;
  bulk_price: string | null;
  stock_quantity: number;
  fda_verified: boolean;
  description: string | null;
}

function getWishlist(): string[] {
  try {
    return JSON.parse(localStorage.getItem("wishlist") || "[]");
  } catch {
    return [];
  }
}

function saveWishlist(ids: string[]) {
  localStorage.setItem("wishlist", JSON.stringify(ids));
}

export default function WishlistPage() {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) { window.location.href = "/login"; return; }
    loadWishlistItems();
  }, []);

  const loadWishlistItems = async () => {
    setLoading(true);
    setError("");
    try {
      const ids = getWishlist();
      if (ids.length === 0) {
        setItems([]);
        setLoading(false);
        return;
      }
      // Fetch each product by ID
      const results = await Promise.allSettled(
        ids.map(id =>
          fetch(`${API}/api/products/${id}`).then(r => r.ok ? r.json() : null)
        )
      );
      const loaded: WishlistItem[] = [];
      const validIds: string[] = [];
      results.forEach((r, i) => {
        if (r.status === "fulfilled" && r.value) {
          loaded.push(r.value);
          validIds.push(ids[i]);
        }
      });
      // Clean up stale IDs
      if (validIds.length !== ids.length) saveWishlist(validIds);
      setItems(loaded);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to load wishlist");
    } finally {
      setLoading(false);
    }
  };

  const removeItem = (id: string) => {
    const ids = getWishlist().filter(i => i !== id);
    saveWishlist(ids);
    setItems(prev => prev.filter(p => p.id !== id));
  };

  const clearAll = () => {
    saveWishlist([]);
    setItems([]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">My Wishlist</h1>
          <p className="text-gray-500 text-sm mt-1">{items.length} saved item{items.length !== 1 ? "s" : ""}</p>
        </div>
        {items.length > 0 && (
          <button onClick={clearAll}
            className="text-sm text-red-600 hover:underline">
            🗑️ Clear all
          </button>
        )}
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 mb-4 text-sm">
          ⚠️ {error}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-white rounded-xl border p-5 animate-pulse space-y-3">
              <div className="h-5 bg-gray-200 rounded w-3/4" />
              <div className="h-4 bg-gray-200 rounded w-1/2" />
              <div className="h-4 bg-gray-200 rounded w-full" />
              <div className="h-8 bg-gray-200 rounded w-1/3" />
            </div>
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-20">
          <span className="text-5xl block mb-4">❤️</span>
          <p className="text-gray-600 text-lg font-medium">Your wishlist is empty</p>
          <p className="text-gray-400 text-sm mt-2">Save products from the marketplace to revisit them later.</p>
          <a href="/marketplace"
            className="mt-6 inline-block bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm hover:bg-blue-800 transition font-medium">
            🏪 Browse Marketplace
          </a>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {items.map(p => (
            <div key={p.id} className="bg-white rounded-xl border shadow-sm hover:shadow-md transition overflow-hidden">
              <div className="p-5">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-base leading-tight">{p.name}</h3>
                    {p.brand && (
                      <p className="text-xs text-gray-500 mt-0.5">{p.brand}{p.model_number ? ` • ${p.model_number}` : ""}</p>
                    )}
                  </div>
                  <button onClick={() => removeItem(p.id)}
                    className="text-gray-400 hover:text-red-600 transition text-lg leading-none mt-0.5"
                    title="Remove from wishlist">
                    ✕
                  </button>
                </div>

                {p.description && (
                  <p className="text-sm text-gray-600 mt-2 line-clamp-2">{p.description}</p>
                )}

                <div className="flex items-end justify-between mt-4">
                  <div>
                    {p.unit_price
                      ? <p className="text-lg font-bold text-blue-700">₱{Number(p.unit_price).toLocaleString()}</p>
                      : <p className="text-sm text-gray-400">Price on request</p>}
                    {p.bulk_price && (
                      <p className="text-xs text-gray-500">Bulk: ₱{Number(p.bulk_price).toLocaleString()}</p>
                    )}
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${p.stock_quantity > 0 ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
                    {p.stock_quantity > 0 ? `${p.stock_quantity} in stock` : "Out of stock"}
                  </span>
                </div>

                <div className="flex items-center gap-2 mt-4">
                  {p.fda_verified && (
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">FDA ✓</span>
                  )}
                  <a href={`/marketplace/${p.id}`}
                    className="flex-1 text-center text-sm bg-blue-700 text-white px-3 py-2 rounded-lg hover:bg-blue-800 transition font-medium">
                    View Product
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
