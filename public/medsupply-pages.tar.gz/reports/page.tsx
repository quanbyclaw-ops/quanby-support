"use client";
import { useState, useEffect } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "https://medsupply.quanbyai.com";

interface OrderItem {
  id: string;
  product_id: string;
  quantity: number;
  unit_price: string;
  total_price: string;
}

interface Order {
  id: string;
  order_number: string;
  status: string;
  subtotal: string;
  vat: string;
  total: string;
  created_at: string;
  items: OrderItem[];
}

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-gray-100 text-gray-700",
  pending_approval: "bg-yellow-100 text-yellow-700",
  approved: "bg-blue-100 text-blue-700",
  processing: "bg-purple-100 text-purple-700",
  shipped: "bg-indigo-100 text-indigo-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
  returned: "bg-orange-100 text-orange-700",
};

function StatCard({ icon, title, value, sub }: { icon: string; title: string; value: string; sub?: string }) {
  return (
    <div className="bg-white rounded-xl border p-5 hover:shadow-md transition">
      <div className="text-2xl mb-2">{icon}</div>
      <h3 className="text-sm text-gray-500">{title}</h3>
      <p className="text-2xl font-bold mt-1">{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
    </div>
  );
}

export default function ReportsPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [dateRange, setDateRange] = useState("all");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) { window.location.href = "/login"; return; }
    fetchOrders(token);
  }, []);

  const fetchOrders = async (token: string) => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/orders/?page_size=100`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch orders");
      const data = await res.json();
      setOrders(data.items || []);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to fetch data");
    } finally {
      setLoading(false);
    }
  };

  // Filter by date range
  const filteredOrders = orders.filter(o => {
    if (dateRange === "all") return true;
    const created = new Date(o.created_at);
    const now = new Date();
    if (dateRange === "7d") return (now.getTime() - created.getTime()) <= 7 * 86400000;
    if (dateRange === "30d") return (now.getTime() - created.getTime()) <= 30 * 86400000;
    if (dateRange === "90d") return (now.getTime() - created.getTime()) <= 90 * 86400000;
    return true;
  });

  // Compute stats
  const totalRevenue = filteredOrders
    .filter(o => !["cancelled", "returned", "draft"].includes(o.status))
    .reduce((sum, o) => sum + Number(o.total || 0), 0);

  const completedOrders = filteredOrders.filter(o => o.status === "delivered");
  const pendingOrders = filteredOrders.filter(o => ["pending_approval", "approved", "processing", "shipped"].includes(o.status));
  const totalVAT = filteredOrders
    .filter(o => !["cancelled", "returned", "draft"].includes(o.status))
    .reduce((sum, o) => sum + Number(o.vat || 0), 0);

  const handleExport = () => {
    const rows = [
      ["Order #", "Status", "Date", "Subtotal", "VAT", "Total"],
      ...filteredOrders.map(o => [
        o.order_number,
        o.status,
        new Date(o.created_at).toLocaleDateString("en-PH"),
        Number(o.subtotal).toFixed(2),
        Number(o.vat).toFixed(2),
        Number(o.total).toFixed(2),
      ]),
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `medsupply-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Sales Reports</h1>
          <p className="text-gray-500 text-sm mt-1">Overview of your sales performance</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={dateRange}
            onChange={e => setDateRange(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            <option value="all">All Time</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 border px-4 py-2 rounded-lg text-sm hover:bg-gray-50 transition"
          >
            📥 Export CSV
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 mb-4 text-sm">
          ⚠️ {error}
        </div>
      )}

      {/* Stats Grid */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-xl border p-5 animate-pulse space-y-2">
              <div className="h-8 w-8 bg-gray-200 rounded" />
              <div className="h-4 bg-gray-200 rounded w-2/3" />
              <div className="h-6 bg-gray-200 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 mb-8">
          <StatCard
            icon="💰"
            title="Total Revenue"
            value={`₱${totalRevenue.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            sub="Excl. cancelled orders"
          />
          <StatCard
            icon="🛒"
            title="Total Orders"
            value={String(filteredOrders.length)}
            sub={`${completedOrders.length} completed`}
          />
          <StatCard
            icon="⏳"
            title="Pending Orders"
            value={String(pendingOrders.length)}
            sub="In progress"
          />
          <StatCard
            icon="🧾"
            title="VAT Collected"
            value={`₱${totalVAT.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            sub="12% VAT"
          />
        </div>
      )}

      {/* Orders Table */}
      <div className="bg-white rounded-xl border overflow-hidden">
        <div className="px-6 py-4 border-b flex justify-between items-center">
          <h2 className="font-semibold text-base">Recent Orders</h2>
          <span className="text-sm text-gray-500">{filteredOrders.length} records</span>
        </div>

        {loading ? (
          <div className="divide-y">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-6 py-4 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-1/4" />
                <div className="h-4 bg-gray-200 rounded w-1/6" />
                <div className="h-4 bg-gray-200 rounded w-1/6" />
                <div className="h-4 bg-gray-200 rounded w-1/5" />
              </div>
            ))}
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-12">
            <span className="text-4xl block mb-3">📊</span>
            <p className="text-gray-500">No orders found for this period.</p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-left px-6 py-3 font-semibold text-gray-600">Order #</th>
                    <th className="text-left px-4 py-3 font-semibold text-gray-600">Date</th>
                    <th className="text-center px-4 py-3 font-semibold text-gray-600">Status</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-600">Subtotal</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-600">VAT</th>
                    <th className="text-right px-6 py-3 font-semibold text-gray-600">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredOrders.map(o => (
                    <tr key={o.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4">
                        <a href={`/orders/${o.id}`} className="font-medium text-blue-700 hover:underline">
                          {o.order_number}
                        </a>
                      </td>
                      <td className="px-4 py-4 text-gray-600">
                        {new Date(o.created_at).toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric" })}
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${STATUS_COLORS[o.status] || "bg-gray-100 text-gray-700"}`}>
                          {o.status.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-right text-gray-700">
                        ₱{Number(o.subtotal).toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-4 py-4 text-right text-gray-500">
                        ₱{Number(o.vat).toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-6 py-4 text-right font-semibold text-gray-900">
                        ₱{Number(o.total).toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
                {/* Footer totals */}
                <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                  <tr>
                    <td colSpan={3} className="px-6 py-3 text-sm font-semibold text-gray-600">Totals</td>
                    <td className="px-4 py-3 text-right font-semibold">
                      ₱{filteredOrders.reduce((s, o) => s + Number(o.subtotal || 0), 0).toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 text-right text-gray-500 font-semibold">
                      ₱{totalVAT.toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-6 py-3 text-right font-bold text-blue-700">
                      ₱{filteredOrders.reduce((s, o) => s + Number(o.total || 0), 0).toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden divide-y">
              {filteredOrders.map(o => (
                <div key={o.id} className="px-4 py-4">
                  <div className="flex justify-between items-start">
                    <a href={`/orders/${o.id}`} className="font-medium text-blue-700">{o.order_number}</a>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${STATUS_COLORS[o.status] || "bg-gray-100 text-gray-700"}`}>
                      {o.status.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {new Date(o.created_at).toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric" })}
                  </div>
                  <div className="flex justify-between mt-2 text-sm">
                    <span className="text-gray-500">Total</span>
                    <span className="font-semibold">₱{Number(o.total).toLocaleString("en-PH", { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
