"use client";
import { useState, useEffect, useCallback } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "https://medsupply.quanbyai.com";

interface Product {
  id: string;
  name: string;
  brand: string | null;
  model_number: string | null;
  unit_price: string | null;
  stock_quantity: number;
  fda_verified: boolean;
  is_active: boolean;
  is_approved: boolean;
  description: string | null;
  category_id: string | null;
  created_at: string;
  company?: { name: string } | null;
  supplier?: { first_name: string; last_name: string; email: string } | null;
}

const APPROVAL_COLORS: Record<string, string> = {
  true: "bg-green-100 text-green-700",
  false: "bg-yellow-100 text-yellow-700",
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [bulkLoading, setBulkLoading] = useState(false);

  const fetchProducts = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!token) { window.location.href = "/login"; return; }

    // Admin guard: check role
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    if (user.role !== "admin") { window.location.href = "/dashboard"; return; }

    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams({ page: String(page), page_size: "20" });
      if (search) params.set("search", search);
      if (statusFilter === "pending") params.set("is_approved", "false");
      if (statusFilter === "approved") params.set("is_approved", "true");
      if (statusFilter === "inactive") params.set("is_active", "false");

      const res = await fetch(`${API}/api/products/?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch products");
      const data = await res.json();
      setProducts(data.items || []);
      setTotal(data.total || 0);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to fetch products");
    } finally {
      setLoading(false);
    }
  }, [page, search, statusFilter]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const approveProduct = async (id: string, approve: boolean) => {
    const token = localStorage.getItem("token");
    if (!token) return;
    setActionLoading(id);
    try {
      const res = await fetch(`${API}/api/products/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ is_approved: approve, is_active: approve }),
      });
      if (!res.ok) throw new Error("Action failed");
      setProducts(prev => prev.map(p => p.id === id ? { ...p, is_approved: approve, is_active: approve } : p));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Action failed");
    } finally {
      setActionLoading(null);
    }
  };

  const bulkApprove = async (approve: boolean) => {
    const token = localStorage.getItem("token");
    if (!token || selected.size === 0) return;
    setBulkLoading(true);
    try {
      await Promise.all(
        Array.from(selected).map(id =>
          fetch(`${API}/api/products/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
            body: JSON.stringify({ is_approved: approve, is_active: approve }),
          })
        )
      );
      setSelected(new Set());
      fetchProducts();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Bulk action failed");
    } finally {
      setBulkLoading(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selected.size === products.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(products.map(p => p.id)));
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">All Products</h1>
          <p className="text-gray-500 text-sm mt-1">Admin view — {total} total product{total !== 1 ? "s" : ""}</p>
        </div>
        <div className="flex items-center gap-2 text-xs bg-red-50 text-red-700 border border-red-200 px-3 py-1.5 rounded-full">
          🔒 Admin Access
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px]">
          <span className="absolute left-3 top-3 text-gray-400">🔍</span>
          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            className="w-full border rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <select
          value={statusFilter}
          onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
          className="border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="all">All Status</option>
          <option value="pending">Pending Approval</option>
          <option value="approved">Approved</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>

      {/* Bulk actions */}
      {selected.size > 0 && (
        <div className="flex items-center gap-3 bg-blue-50 border border-blue-200 rounded-lg px-4 py-3 mb-4">
          <span className="text-sm text-blue-700 font-medium">{selected.size} selected</span>
          <div className="flex gap-2 ml-auto">
            <button
              onClick={() => bulkApprove(true)}
              disabled={bulkLoading}
              className="text-xs bg-green-600 text-white px-3 py-1.5 rounded-lg hover:bg-green-700 transition disabled:opacity-50"
            >
              ✅ Approve All
            </button>
            <button
              onClick={() => bulkApprove(false)}
              disabled={bulkLoading}
              className="text-xs bg-red-600 text-white px-3 py-1.5 rounded-lg hover:bg-red-700 transition disabled:opacity-50"
            >
              ❌ Reject All
            </button>
            <button
              onClick={() => setSelected(new Set())}
              className="text-xs border px-3 py-1.5 rounded-lg hover:bg-gray-50 transition"
            >
              Clear
            </button>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 mb-4 text-sm">
          ⚠️ {error}
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl border overflow-hidden">
        {loading ? (
          <div className="divide-y">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-6 py-4 animate-pulse">
                <div className="h-4 w-4 bg-gray-200 rounded" />
                <div className="h-4 bg-gray-200 rounded w-1/3" />
                <div className="h-4 bg-gray-200 rounded w-1/5" />
                <div className="h-4 bg-gray-200 rounded w-1/6" />
                <div className="h-4 bg-gray-200 rounded w-1/8" />
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16">
            <span className="text-4xl block mb-4">📦</span>
            <p className="text-gray-500 text-lg">No products found</p>
            <p className="text-gray-400 text-sm mt-2">Adjust your filters to see products.</p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selected.size === products.length && products.length > 0}
                        onChange={toggleSelectAll}
                        className="rounded"
                      />
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-gray-600">Product</th>
                    <th className="text-left px-4 py-3 font-semibold text-gray-600">Seller / Company</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-600">Price</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-600">Stock</th>
                    <th className="text-center px-4 py-3 font-semibold text-gray-600">Approval</th>
                    <th className="text-center px-4 py-3 font-semibold text-gray-600">Active</th>
                    <th className="text-right px-6 py-3 font-semibold text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {products.map(p => (
                    <tr key={p.id} className={`hover:bg-gray-50 transition ${selected.has(p.id) ? "bg-blue-50/40" : ""}`}>
                      <td className="px-4 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={selected.has(p.id)}
                          onChange={() => toggleSelect(p.id)}
                          className="rounded"
                        />
                      </td>
                      <td className="px-4 py-4">
                        <div className="font-medium text-gray-900">{p.name}</div>
                        {p.brand && <div className="text-xs text-gray-500">{p.brand} {p.model_number ? `• ${p.model_number}` : ""}</div>}
                        {p.fda_verified && (
                          <span className="inline-block text-xs bg-green-100 text-green-700 px-1.5 py-0.5 rounded mt-1">FDA ✓</span>
                        )}
                      </td>
                      <td className="px-4 py-4">
                        {p.company ? (
                          <div className="text-gray-700 font-medium">{p.company.name}</div>
                        ) : p.supplier ? (
                          <div>
                            <div className="text-gray-700">{p.supplier.first_name} {p.supplier.last_name}</div>
                            <div className="text-xs text-gray-400">{p.supplier.email}</div>
                          </div>
                        ) : (
                          <span className="text-gray-400 text-xs">Unknown</span>
                        )}
                      </td>
                      <td className="px-4 py-4 text-right font-medium">
                        {p.unit_price ? `₱${Number(p.unit_price).toLocaleString()}` : "—"}
                      </td>
                      <td className="px-4 py-4 text-right">
                        <span className={`font-medium ${p.stock_quantity === 0 ? "text-red-600" : p.stock_quantity < 10 ? "text-yellow-600" : "text-gray-900"}`}>
                          {p.stock_quantity}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${APPROVAL_COLORS[String(p.is_approved)]}`}>
                          {p.is_approved ? "Approved" : "Pending"}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${p.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                          {p.is_active ? "Yes" : "No"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {!p.is_approved ? (
                            <button
                              onClick={() => approveProduct(p.id, true)}
                              disabled={actionLoading === p.id}
                              className="text-xs bg-green-600 text-white px-3 py-1.5 rounded-lg hover:bg-green-700 transition disabled:opacity-50"
                            >
                              {actionLoading === p.id ? "..." : "✅ Approve"}
                            </button>
                          ) : (
                            <button
                              onClick={() => approveProduct(p.id, false)}
                              disabled={actionLoading === p.id}
                              className="text-xs border border-red-200 text-red-600 px-3 py-1.5 rounded-lg hover:bg-red-50 transition disabled:opacity-50"
                            >
                              {actionLoading === p.id ? "..." : "❌ Reject"}
                            </button>
                          )}
                          <a
                            href={`/marketplace/${p.id}`}
                            className="text-xs border px-3 py-1.5 rounded-lg hover:bg-gray-50 transition text-gray-600"
                          >
                            👁️ View
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="lg:hidden divide-y">
              {products.map(p => (
                <div key={p.id} className={`px-4 py-4 ${selected.has(p.id) ? "bg-blue-50/40" : ""}`}>
                  <div className="flex items-start gap-3">
                    <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggleSelect(p.id)} className="rounded mt-0.5" />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-gray-900 text-sm">{p.name}</div>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ml-2 ${APPROVAL_COLORS[String(p.is_approved)]}`}>
                          {p.is_approved ? "Approved" : "Pending"}
                        </span>
                      </div>
                      {p.brand && <div className="text-xs text-gray-500">{p.brand}</div>}
                      {p.company && <div className="text-xs text-gray-600 mt-1">🏢 {p.company.name}</div>}
                      <div className="flex gap-2 mt-3">
                        {!p.is_approved ? (
                          <button onClick={() => approveProduct(p.id, true)} disabled={actionLoading === p.id}
                            className="flex-1 text-xs bg-green-600 text-white px-3 py-1.5 rounded-lg hover:bg-green-700 disabled:opacity-50">
                            ✅ Approve
                          </button>
                        ) : (
                          <button onClick={() => approveProduct(p.id, false)} disabled={actionLoading === p.id}
                            className="flex-1 text-xs border border-red-200 text-red-600 px-3 py-1.5 rounded-lg hover:bg-red-50 disabled:opacity-50">
                            ❌ Reject
                          </button>
                        )}
                        <a href={`/marketplace/${p.id}`}
                          className="flex-1 text-center text-xs border px-3 py-1.5 rounded-lg hover:bg-gray-50 text-gray-600">
                          👁️ View
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Pagination */}
      {total > 20 && (
        <div className="flex justify-center items-center gap-4 mt-6">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
            className="px-4 py-2 border rounded-lg disabled:opacity-50 hover:bg-gray-50 text-sm">← Previous</button>
          <span className="text-sm text-gray-500">Page {page} of {Math.ceil(total / 20)}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={products.length < 20}
            className="px-4 py-2 border rounded-lg disabled:opacity-50 hover:bg-gray-50 text-sm">Next →</button>
        </div>
      )}
    </div>
  );
}
