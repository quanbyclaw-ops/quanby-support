"use client";
import { useState, useEffect, useCallback } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "https://medsupply.quanbyai.com";

interface Product {
  id: string;
  name: string;
  brand: string | null;
  model_number: string | null;
  unit_price: string | null;
  bulk_price: string | null;
  stock_quantity: number;
  fda_verified: boolean;
  is_active: boolean;
  description: string | null;
  category_id: string | null;
  created_at: string;
}

const STATUS_COLORS: Record<string, string> = {
  true: "bg-green-100 text-green-700",
  false: "bg-gray-100 text-gray-600",
};

export default function MyProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const fetchProducts = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!token) { window.location.href = "/login"; return; }
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams({ page: String(page), page_size: "20" });
      if (search) params.set("search", search);
      const res = await fetch(`${API}/api/products/?${params}&mine=true`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch products");
      const data = await res.json();
      setProducts(data.items || []);
      setTotal(data.total || 0);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to fetch products");
    } finally {
      setLoading(false);
    }
  }, [page, search]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const handleDelete = async (id: string) => {
    const token = localStorage.getItem("token");
    if (!token) return;
    setDeleting(true);
    try {
      const res = await fetch(`${API}/api/products/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to delete product");
      setDeleteConfirm(null);
      fetchProducts();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">My Products</h1>
          <p className="text-gray-500 text-sm mt-1">{total} product{total !== 1 ? "s" : ""} listed</p>
        </div>
        <a
          href="/products/new"
          className="flex items-center gap-2 bg-blue-700 text-white px-4 py-2.5 rounded-lg hover:bg-blue-800 transition text-sm font-medium"
        >
          ➕ Add New Product
        </a>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <span className="absolute left-3 top-3 text-gray-400">🔍</span>
        <input
          type="text"
          placeholder="Search by product name..."
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(1); }}
          className="w-full border rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 mb-4 text-sm">
          ⚠️ {error}
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl border overflow-hidden">
        {loading ? (
          <div className="divide-y">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-6 py-4 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-1/3" />
                <div className="h-4 bg-gray-200 rounded w-1/6" />
                <div className="h-4 bg-gray-200 rounded w-1/6" />
                <div className="h-4 bg-gray-200 rounded w-1/8" />
                <div className="h-4 bg-gray-200 rounded w-1/8" />
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16">
            <span className="text-4xl block mb-4">📦</span>
            <p className="text-gray-500 text-lg">No products yet</p>
            <p className="text-gray-400 text-sm mt-2">Add your first product to start selling on MedSupply.</p>
            <a href="/products/new" className="mt-4 inline-block bg-blue-700 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-800 transition">
              ➕ Add Product
            </a>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-left px-6 py-3 font-semibold text-gray-600">Product</th>
                    <th className="text-left px-4 py-3 font-semibold text-gray-600">SKU / Model</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-600">Unit Price</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-600">Stock</th>
                    <th className="text-center px-4 py-3 font-semibold text-gray-600">Status</th>
                    <th className="text-right px-6 py-3 font-semibold text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {products.map(p => (
                    <tr key={p.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{p.name}</div>
                        {p.brand && <div className="text-xs text-gray-500 mt-0.5">{p.brand}</div>}
                        {p.fda_verified && (
                          <span className="inline-block text-xs bg-green-100 text-green-700 px-1.5 py-0.5 rounded mt-1">FDA ✓</span>
                        )}
                      </td>
                      <td className="px-4 py-4 text-gray-600">{p.model_number || "—"}</td>
                      <td className="px-4 py-4 text-right font-medium">
                        {p.unit_price ? `₱${Number(p.unit_price).toLocaleString()}` : "—"}
                      </td>
                      <td className="px-4 py-4 text-right">
                        <span className={`font-medium ${p.stock_quantity === 0 ? "text-red-600" : p.stock_quantity < 10 ? "text-yellow-600" : "text-gray-900"}`}>
                          {p.stock_quantity}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${STATUS_COLORS[String(p.is_active)]}`}>
                          {p.is_active ? "Active" : "Inactive"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <a href={`/products/${p.id}/edit`}
                            className="text-xs border px-3 py-1.5 rounded-lg hover:bg-gray-50 transition text-gray-600">
                            ✏️ Edit
                          </a>
                          <button
                            onClick={() => setDeleteConfirm(p.id)}
                            className="text-xs border border-red-200 px-3 py-1.5 rounded-lg hover:bg-red-50 transition text-red-600">
                            🗑️ Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden divide-y">
              {products.map(p => (
                <div key={p.id} className="px-4 py-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{p.name}</div>
                      {p.brand && <div className="text-xs text-gray-500">{p.brand}</div>}
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ml-2 ${STATUS_COLORS[String(p.is_active)]}`}>
                      {p.is_active ? "Active" : "Inactive"}
                    </span>
                  </div>
                  <div className="flex gap-4 mt-2 text-sm text-gray-600">
                    <span>{p.unit_price ? `₱${Number(p.unit_price).toLocaleString()}` : "No price"}</span>
                    <span>Stock: <strong className={p.stock_quantity === 0 ? "text-red-600" : "text-gray-900"}>{p.stock_quantity}</strong></span>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <a href={`/products/${p.id}/edit`}
                      className="flex-1 text-center text-xs border px-3 py-1.5 rounded-lg hover:bg-gray-50 transition text-gray-600">
                      ✏️ Edit
                    </a>
                    <button onClick={() => setDeleteConfirm(p.id)}
                      className="flex-1 text-xs border border-red-200 px-3 py-1.5 rounded-lg hover:bg-red-50 transition text-red-600">
                      🗑️ Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Pagination */}
      {total > 20 && (
        <div className="flex justify-center items-center gap-4 mt-6">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
            className="px-4 py-2 border rounded-lg disabled:opacity-50 hover:bg-gray-50 text-sm">← Previous</button>
          <span className="text-sm text-gray-500">Page {page} of {Math.ceil(total / 20)}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={products.length < 20}
            className="px-4 py-2 border rounded-lg disabled:opacity-50 hover:bg-gray-50 text-sm">Next →</button>
        </div>
      )}

      {/* Delete Confirm Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-semibold mb-2">Delete Product?</h3>
            <p className="text-gray-500 text-sm mb-6">
              This action cannot be undone. The product will be permanently removed.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)}
                className="flex-1 border px-4 py-2 rounded-lg text-sm hover:bg-gray-50 transition">
                Cancel
              </button>
              <button onClick={() => handleDelete(deleteConfirm)} disabled={deleting}
                className="flex-1 bg-red-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-red-700 transition disabled:opacity-50">
                {deleting ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
